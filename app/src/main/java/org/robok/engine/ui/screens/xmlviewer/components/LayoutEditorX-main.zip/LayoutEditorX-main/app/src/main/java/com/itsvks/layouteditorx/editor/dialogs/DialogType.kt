package com.itsvks.layouteditorx.editor.dialogs

enum class DialogType {
  SIZE, DIMENSION, ID, VIEW, BOOLEAN, DRAWABLE, STRING, TEXT, INT, FLOAT, FLAG, ENUM, COLOR
}