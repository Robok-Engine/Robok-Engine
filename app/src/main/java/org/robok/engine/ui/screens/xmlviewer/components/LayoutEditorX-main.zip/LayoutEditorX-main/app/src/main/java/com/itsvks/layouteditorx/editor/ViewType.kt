package com.itsvks.layouteditorx.editor

enum class ViewType {
  DESIGN, BLUEPRINT
}