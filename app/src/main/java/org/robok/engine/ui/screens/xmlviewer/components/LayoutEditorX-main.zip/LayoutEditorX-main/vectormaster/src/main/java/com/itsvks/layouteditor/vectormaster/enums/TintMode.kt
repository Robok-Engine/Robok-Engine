package com.itsvks.layouteditor.vectormaster.enums

enum class TintMode {
  ADD,
  MULTIPLY,
  SCREEN,
  SRC_ATOP,
  SCR_IN,
  SRC_OVER
}
