package com.itsvks.layouteditorx.models

data class ValuesItem(var name: String, var value: String)