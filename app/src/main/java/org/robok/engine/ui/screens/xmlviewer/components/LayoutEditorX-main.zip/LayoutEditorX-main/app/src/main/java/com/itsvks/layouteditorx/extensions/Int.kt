package com.itsvks.layouteditorx.extensions

fun Int.toHexColor() = String.format("%08X", this)