package com.itsvks.layouteditorx.viemodels

import androidx.lifecycle.ViewModel

class EditorViewModel : ViewModel() {
}