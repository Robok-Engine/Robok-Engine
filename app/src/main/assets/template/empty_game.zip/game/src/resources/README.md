# Structure
- images: your all images, PNGs JPGs etc
- objects: your all .obj(s) objects
- texts: your texts, titles etcs...
- shaders: your .vert & .frag shaders