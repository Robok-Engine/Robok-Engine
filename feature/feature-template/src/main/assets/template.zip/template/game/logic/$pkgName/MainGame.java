package $pkgName;

import robok.game.screen.GameScreen;
import robok.game.util.view.Find;
import $pkgName.datagui.MainGui;

public class MainScreen extends GameScreen {
    
    Button shootButton;
    
    @Override
    public void onScreenCreated () {
         shootButton = Find(
    }
}